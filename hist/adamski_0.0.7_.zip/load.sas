filename PB64CE1D list;

 %put NOTE- ;
 %put NOTE: Loading package Adamski, version 0.0.7, license Apache license 2.0; 
 %put NOTE: *** %superq(packageTitle) ***; 
 %put NOTE- Generated: 2026-03-14T16:37:30; 
 %put NOTE- Author(s): %superq(packageAuthor); 
 %put NOTE- Maintainer(s): %superq(packageMaintainer); 
 %put NOTE- ;
 %put NOTE- Run %nrstr(%%)helpPackage(Adamski) for the description;
 %put NOTE- ;
 %put NOTE- *** START ***; 

data _null_; 
 if NOT ("*"=symget("cherryPick")) then do; 
  put "NOTE- "; 
  put "NOTE: *** Cherry Picking ***"; 
  put "NOTE- Cherry Picking in action!! Be advised that"; 
  put "NOTE- dependencies/required packages will not be loaded!"; 
  put "NOTE- "; 
 end; 
run; 
%include  PB64CE1D(packagemetadata.sas) / nosource2; 

 data _null_;                                                     
  call symputX("packageRequiredErrors", 0, "L");                  
 run;                                                             
 %put NOTE- *Testing required SAS components*%sysfunc(DoSubL(
 options nonotes nosource %str(;)                            
 options ls=max ps=max locale=en_US %str(;)                  
 /* temporary redirect log */                                
 filename _stinit_ TEMP %str(;)                              
 proc printto log = _stinit_ %str(;) run %str(;)             
 /* print out setinit */                                     
 proc setinit %str(;) run %str(;)                            
 proc printto %str(;) run %str(;)                            
 options ps=min %str(;)                                      
 data _null_ %str(;)                                         
   /* loadup checklist of required SAS components */         
   if _n_ = 1 then                                           
     do %str(;)                                              
       length req $ 256 %str(;)                              
       declare hash R() %str(;)                              
       _N_ = R.defineKey("req") %str(;)                      
       _N_ = R.defineDone() %str(;)                          
       declare hiter iR("R") %str(;)                         
         do req = %bquote(
"BASE SAS SOFTWARE"
) %str(;)   
          _N_ = R.add(key:req,data:req) %str(;)              
         end %str(;)                                         
     end %str(;)                                             
                                                             
   /* read in output from proc setinit */                    
   infile _stinit_ end=eof %str(;)                           
   input %str(;)                                             
                                                             
   /* if component is in setinit remove it from checklist */ 
   if _infile_ =: "---" then                                 
     do %str(;)                                              
       req = upcase(substr(_infile_, 4, 64)) %str(;)         
       if R.find(key:req) = 0 then                           
         do %str(;)                                          
           _N_ = R.remove() %str(;)                          
         end %str(;)                                         
     end %str(;)                                             
                                                             
   /* if checklist is not null rise error */                 
   if eof and R.num_items > 0 then                           
     do %str(;)                                              
       put "WARNING- ###########################################" %str(;) 
       put "WARNING:  The following SAS components are missing! " %str(;) 
       call symputX("packageRequiredErrors", 0, "L") %str(;)              
       do while(iR.next() = 0) %str(;)                                    
         put "WARNING-   " req %str(;)                                    
       end %str(;)                                                        
       put "WARNING:  The package may NOT WORK as expected      " %str(;) 
       put "WARNING:  or even result with ERRORS!               " %str(;) 
       put "WARNING- ###########################################" %str(;) 
       put %str(;)                                           
     end %str(;)                                             
 run %str(;)                                                 
 filename _stinit_ clear %str(;)                             
 options notes source %str(;)                                
 ))*;                                                        
 %let temp_noNotes_etc=%sysfunc(getoption(NOTES));
 options noNotes;
 data _null_;                                                     
  if 1 = symgetn("packageRequiredErrors") then                    
    do;                                                           
      put "ERROR: Loading package &packageName. will be aborted!";
      put "ERROR- Required components are missing.";              
      put "ERROR- *** STOP ***";                                  
      call symputX("packageRequiredErrors",
     'options ls = &ls_tmp. ps = &ps_tmp. 
       &notes_tmp. &source_tmp. msglevel=&msglevel_tmp. 
       &stimer_tmp. &fullstimer_tmp. ;
       data _null_;abort;run;', "L");              
    end;                                            
  else                                              
    call symputX("packageRequiredErrors", " ", "L");
 run;                                               
 &packageRequiredErrors.                            
 options &temp_noNotes_etc.;                        
 
%if (%str(*)=%superq(cherryPick)) or (derive_locf_records in %superq(cherryPick)) %then %do; 
  %put NOTE- ;
  %put NOTE: >> Element of type macro from the file "derive_locf_records.sas" will be included <<;
  %put %sysfunc(ifc(%SYSMACEXIST(derive_locf_records)=1, NOTE# Macro derive_locf_records exist. It will be overwritten by the macro from the Adamski package, ));
  %include PB64CE1D(_06_macro.derive_locf_records.sas) / nosource2;
%end; 

 
%if (%str(*)=%superq(cherryPick)) or (derive_var_age_years in %superq(cherryPick)) %then %do; 
  %put NOTE- ;
  %put NOTE: >> Element of type macro from the file "derive_var_age_years.sas" will be included <<;
  %put %sysfunc(ifc(%SYSMACEXIST(derive_var_age_years)=1, NOTE# Macro derive_var_age_years exist. It will be overwritten by the macro from the Adamski package, ));
  %include PB64CE1D(_06_macro.derive_var_age_years.sas) / nosource2;
%end; 

 
%if (%str(*)=%superq(cherryPick)) or (derive_var_base in %superq(cherryPick)) %then %do; 
  %put NOTE- ;
  %put NOTE: >> Element of type macro from the file "derive_var_base.sas" will be included <<;
  %put %sysfunc(ifc(%SYSMACEXIST(derive_var_base)=1, NOTE# Macro derive_var_base exist. It will be overwritten by the macro from the Adamski package, ));
  %include PB64CE1D(_06_macro.derive_var_base.sas) / nosource2;
%end; 

 
%if (%str(*)=%superq(cherryPick)) or (derive_var_chg in %superq(cherryPick)) %then %do; 
  %put NOTE- ;
  %put NOTE: >> Element of type macro from the file "derive_var_chg.sas" will be included <<;
  %put %sysfunc(ifc(%SYSMACEXIST(derive_var_chg)=1, NOTE# Macro derive_var_chg exist. It will be overwritten by the macro from the Adamski package, ));
  %include PB64CE1D(_06_macro.derive_var_chg.sas) / nosource2;
%end; 

 
%if (%str(*)=%superq(cherryPick)) or (derive_var_merged_exist_flag in %superq(cherryPick)) %then %do; 
  %put NOTE- ;
  %put NOTE: >> Element of type macro from the file "derive_var_merged_exist_flag.sas" will be included <<;
  %put %sysfunc(ifc(%SYSMACEXIST(derive_var_merged_exist_flag)=1, NOTE# Macro derive_var_merged_exist_flag exist. It will be overwritten by the macro from the Adamski package, ));
  %include PB64CE1D(_06_macro.derive_var_merged_exist_flag.sas) / nosource2;
%end; 

 
%if (%str(*)=%superq(cherryPick)) or (derive_var_obs_number in %superq(cherryPick)) %then %do; 
  %put NOTE- ;
  %put NOTE: >> Element of type macro from the file "derive_var_obs_number.sas" will be included <<;
  %put %sysfunc(ifc(%SYSMACEXIST(derive_var_obs_number)=1, NOTE# Macro derive_var_obs_number exist. It will be overwritten by the macro from the Adamski package, ));
  %include PB64CE1D(_06_macro.derive_var_obs_number.sas) / nosource2;
%end; 

 
%if (%str(*)=%superq(cherryPick)) or (derive_vars_aage in %superq(cherryPick)) %then %do; 
  %put NOTE- ;
  %put NOTE: >> Element of type macro from the file "derive_vars_aage.sas" will be included <<;
  %put %sysfunc(ifc(%SYSMACEXIST(derive_vars_aage)=1, NOTE# Macro derive_vars_aage exist. It will be overwritten by the macro from the Adamski package, ));
  %include PB64CE1D(_06_macro.derive_vars_aage.sas) / nosource2;
%end; 

 
%if (%str(*)=%superq(cherryPick)) or (derive_vars_cat in %superq(cherryPick)) %then %do; 
  %put NOTE- ;
  %put NOTE: >> Element of type macro from the file "derive_vars_cat.sas" will be included <<;
  %put %sysfunc(ifc(%SYSMACEXIST(derive_vars_cat)=1, NOTE# Macro derive_vars_cat exist. It will be overwritten by the macro from the Adamski package, ));
  %include PB64CE1D(_06_macro.derive_vars_cat.sas) / nosource2;
%end; 

 
%if (%str(*)=%superq(cherryPick)) or (derive_vars_duration in %superq(cherryPick)) %then %do; 
  %put NOTE- ;
  %put NOTE: >> Element of type macro from the file "derive_vars_duration.sas" will be included <<;
  %put %sysfunc(ifc(%SYSMACEXIST(derive_vars_duration)=1, NOTE# Macro derive_vars_duration exist. It will be overwritten by the macro from the Adamski package, ));
  %include PB64CE1D(_06_macro.derive_vars_duration.sas) / nosource2;
%end; 

 
%if (%str(*)=%superq(cherryPick)) or (derive_vars_dy in %superq(cherryPick)) %then %do; 
  %put NOTE- ;
  %put NOTE: >> Element of type macro from the file "derive_vars_dy.sas" will be included <<;
  %put %sysfunc(ifc(%SYSMACEXIST(derive_vars_dy)=1, NOTE# Macro derive_vars_dy exist. It will be overwritten by the macro from the Adamski package, ));
  %include PB64CE1D(_06_macro.derive_vars_dy.sas) / nosource2;
%end; 

 
%if (%str(*)=%superq(cherryPick)) or (derive_vars_joined in %superq(cherryPick)) %then %do; 
  %put NOTE- ;
  %put NOTE: >> Element of type macro from the file "derive_vars_joined.sas" will be included <<;
  %put %sysfunc(ifc(%SYSMACEXIST(derive_vars_joined)=1, NOTE# Macro derive_vars_joined exist. It will be overwritten by the macro from the Adamski package, ));
  %include PB64CE1D(_06_macro.derive_vars_joined.sas) / nosource2;
%end; 

data _null_;                                   
  call symputX("cherryPick_CASLUDF",  0, "L"); 
run;                                           
data _null_;                                   
length CASLUDF $ 32767;                        
dtCASLudf = datetime();                        
CASLUDF =                                      
    '%macro AdamskiCASLudf('         
 !! "list=1,depList="                          
 !! ')/ des = ''CASL User Defined Functions loader for Adamski package'';'
 !! '  %if HELP = %superq(list) %then                               '
 !! '    %do;                                                       '
 !! '      %put ****************************************************************************;'
 !! '      %put This is help for the `AdamskiCASLudf` macro;'
 !! '      %put Parameters (optional) are the following:;'
 !! '      %put - `list` indicates if the list of loaded CASL UDFs should be displayed,;'
 !! '      %put %str(  )when set to the value of `1` (the default) runs `FUNCTIONLIST USER%str(;)`,;'
 !! '      %put %str(  )when set to the value of `HELP` (upcase letters!) displays this help message.;'
 !! '      %put - `depList` [technical] contains the list of dependencies required by the package.;'
 !! '      %put %str(  )for _this_ instance of the macro the default value is: `.;'
 !! '      %put The macro generated: ' !! put(dtCASLudf, E8601DT19.-L) !! ";"
 !! '      %put with the SAS Packages Framework version 20260205.;'
 !! '      %put ****************************************************************************;'
 !! '    %GOTO theEndOfTheMacro;'
 !! '    %end;'
 !! '  %if %superq(depList) ne %then                                '
 !! '    %do;                                                       '
 !! '      %do i = 1 %to %sysfunc(countw(&depList.,%str( )));       '
 !! '        %let depListNm = %scan(&depList.,&i.,%str( ));         '
 !! '        %if %SYSMACEXIST(&depListNm.CASLudf) %then             '
 !! '          %do;                                                 '
 !! '            %&depListNm.CASLudf(list=0)                        '
 !! '          %end;                                                '
 !! '      %end;                                                    '
 !! '    %end;                                                      '
 !! '  %local tmp_NOTES;'                           
 !! '  %let tmp_NOTES = %sysfunc(getoption(NOTES));'
 !! "  filename PB64CE1D &ZIP. '&path./adamski.&zip.';"
 !! "  options nonotes;"                      
 !! '  filename PB64CE1D clear;'    
 !! '  options &tmp_NOTES.;'                
 !! '   %if 1 = %superq(list) %then '       
 !! '     %do; '                            
 !! "       FUNCTIONLIST USER;"               
 !! "       run;"                             
 !! '     %end; '                           
 !! '%theEndOfTheMacro: %mend;';            
run;

data _null_;
run;
data _null_;
run;
proc fcmp outlib = work.Adamskifcmp.packagemeta ; 
 function AdamskiMETA(meta $) $ 32767;
  m = char(upcase(meta),1);
   if m = 'V' then return(strip("0.0.7"));
   if m = 'D' then return(strip("2026-03-14T16:37:30"));
   if m = 'A' then return(strip("[Yutaka Morioka],[Hiroki Yamanobe],[Ryo Nakaya],[Sharad Chhetri]"));
   if m = 'M' then return(strip("[Yutaka Morioka],[Hiroki Yamanobe],[Ryo Nakaya],[Sharad Chhetri]"));
   if m = 'T' then return(strip("Adamski -- A SAS package of toolkit for CDISC ADaM creation"));
   if m = 'E' then return(strip("UTF8"));
   if m = 'L' then return(strip("2026-03-14T16:37:30"));
   if m = 'S' then return(strip("""BASE SAS SOFTWARE"""));
  return(" ");
 endfunc;
quit;
%sysfunc(ifc(0<
  %sysfunc(findw((%sysfunc(getoption(cmplib)))
                ,work.adamskifcmp,"'( )'",RIO))
,,%str(options APPEND=(cmplib = work.adamskifcmp);)
))
%macro AdamskiMETA(meta)/parmbuff;
%if %superq(meta) = %then %return;
%do;%qsysfunc(strip(%qsysfunc(AdamskiMETA&syspbuff.)))%end;
%mend;


%put NOTE- ;
%put NOTE:[CMPLIB] %sysfunc(getoption(cmplib));

%if (%str(*)=%superq(cherryPick)) %then %do; 
 %let temp_noNotes_etc=%sysfunc(getoption(NOTES));
 options noNotes;
 data _null_ ;                                                                                              
  length SYSloadedPackages stringPCKG $ 32767;                                                              
  if SYMEXIST("SYSloadedPackages") = 1 and SYMGLOBL("SYSloadedPackages") = 1 then                           
    do;                                                                                                     
      do until(EOF);                                                                                        
        set sashelp.vmacro(where=(scope="GLOBAL" and name="SYSLOADEDPACKAGES")) end=EOF;                    
        substr(SYSloadedPackages, 1+offset, 200) = value;                                                   
      end;                                                                                                  
      SYSloadedPackages = cats("#", translate(strip(SYSloadedPackages), "#", " "), "#");                    
      indexPCKG = INDEX(lowcase(SYSloadedPackages), '#adamski(');                  
      if indexPCKG = 0 then                                                                                 
         do;                                                                                                
          SYSloadedPackages = catx('#', SYSloadedPackages, 'Adamski(0.0.7)');              
          SYSloadedPackages = compbl(translate(SYSloadedPackages, " ", "#"));                               
          call symputX("SYSloadedPackages", SYSloadedPackages, "G");                                        
          put / "INFO: [SYSLOADEDPACKAGES] " SYSloadedPackages ;                                             
         end ;                                                                                              
      else                                                                                                  
         do;                                                                                                
          stringPCKG = kscanx(substr(SYSloadedPackages, indexPCKG+1), 1, '#');                              
          SYSloadedPackages = compbl(tranwrd(SYSloadedPackages, strip(stringPCKG), "#"));                   
          SYSloadedPackages = catx('#', SYSloadedPackages, 'Adamski(0.0.7)');              
          SYSloadedPackages = compbl(translate(SYSloadedPackages, " ", "#"));                               
          call symputX("SYSloadedPackages", SYSloadedPackages, "G");                                        
          put / "INFO: [SYSLOADEDPACKAGES] " SYSloadedPackages ;                                             
         end ;                                                                                              
    end;                                                                                                    
  else                                                                                                      
    do;                                                                                                     
      call symputX('SYSloadedPackages', 'Adamski(0.0.7)', 'G');                            
      put / 'INFO: [SYSLOADEDPACKAGES] Adamski(0.0.7)';                                     
    end;                                                                                                    
  stop;                                                                                                     
 run;                                                                                                       
 options &temp_noNotes_etc.;
%end; 

options NOTES;
%put NOTE- ;
%put NOTE: Loading package Adamski, version %AdamskiMETA(V), license Apache license 2.0;
%put NOTE- *** END ***;

options &temp_noNotes_etc.;
%symdel temp_noNotes_etc / noWarn;
/* load.sas end */

