filename PB64CE1D list;
 %put NOTE- ;
 %put NOTE: Preview of the Adamski package, version 0.0.8, license Apache license 2.0;
 %put NOTE: *** %superq(packageTitle) ***; 
 %put NOTE- Generated: 2026-05-17T10:06:46; 
 %put NOTE- Author(s): %superq(packageAuthor); 
 %put NOTE- Maintainer(s): %superq(packageMaintainer); 
 %put NOTE- ;
 %put NOTE- *** START ***;
%let ls_tmp     = %sysfunc(getoption(ls));         
%let ps_tmp     = %sysfunc(getoption(ps));         
%let notes_tmp  = %sysfunc(getoption(notes));      
%let source_tmp = %sysfunc(getoption(source));     
options ls = MAX ps = MAX nonotes nosource;        
%include PB64CE1D(packagemetadata.sas) / nosource2; 
data _null_;                                                 
  if strip(symget("helpKeyword")) = " " then                 
    do until (EOF);                                          
      infile PB64CE1D(description.sas) end = EOF;  
      input;                                                 
      put _infile_;                                          
    end;                                                     
  else stop;                                                 
run;                                                         
data WORK._%sysfunc(datetime(), hex16.)_;                      
infile cards4 dlm = "/";                                       
input @;                                                       
if 0 then output;                                              
length helpKeyword $ 64;                                       
retain helpKeyword "*";                                        
drop helpKeyword;                                              
if _N_ = 1 then helpKeyword = strip(symget("helpKeyword"));    
if FIND(_INFILE_, helpKeyword, "it") or helpKeyword = "*" then 
 do;                                                           
   input (folder order type file fileshort) (: $ 256.);        
   output;                                                     
 end;                                                          
cards4;                                                        
06_macro/06/macro/derive_basetype_records.sas/derive_basetype_records/'%derive_basetype_records()'
06_macro/06/macro/derive_locf_records.sas/derive_locf_records/'%derive_locf_records()'
06_macro/06/macro/derive_var_age_years.sas/derive_var_age_years/'%derive_var_age_years()'
06_macro/06/macro/derive_var_base.sas/derive_var_base/'%derive_var_base()'
06_macro/06/macro/derive_var_chg.sas/derive_var_chg/'%derive_var_chg()'
06_macro/06/macro/derive_var_merged_exist_flag.sas/derive_var_merged_exist_flag/'%derive_var_merged_exist_flag()'
06_macro/06/macro/derive_var_obs_number.sas/derive_var_obs_number/'%derive_var_obs_number()'
06_macro/06/macro/derive_vars_aage.sas/derive_vars_aage/'%derive_vars_aage()'
06_macro/06/macro/derive_vars_cat.sas/derive_vars_cat/'%derive_vars_cat()'
06_macro/06/macro/derive_vars_duration.sas/derive_vars_duration/'%derive_vars_duration()'
06_macro/06/macro/derive_vars_dy.sas/derive_vars_dy/'%derive_vars_dy()'
06_macro/06/macro/derive_vars_joined.sas/derive_vars_joined/'%derive_vars_joined()'
;;;;
run;
data _null_;                                                                        
if upcase(strip(symget("helpKeyword"))) in (" " "LICENSE") then do; stop; end;      
if NOBS = 0 then do; 
put; put ' *> No preview. Try %previewPackage(packageName,*) to display all.'; put; stop; 
end; 
  do until(EOFDS);                                                                  
   set WORK._last_ end = EOFDS nobs = NOBS;                                         
   length memberX $ 1024;                                                           
   memberX = cats("_",folder,".",file);                                             
   call execute("data _null_;                                                    ");
   call execute('infile PB64CE1D(' || strip(memberX) || ') end = EOF;  ');
   call execute("    do until(EOF);                                              ");
   call execute("      input;                                                    ");
   call execute("      put _infile_;                                             ");
   call execute("    end;                                                        ");
   call execute("  put "" "" / "" "";                                            ");
   call execute("  stop;                                                         ");
   call execute("run;                                                            ");
  end; 
  stop; 
run; 
proc delete data = WORK._last_; 
run; 
options ls = &ls_tmp. ps = &ps_tmp. &notes_tmp. &source_tmp.; 
%put NOTE: Preview of the Adamski package, version 0.0.8, license Apache license 2.0;
%put NOTE- *** END ***;
/* preview.sas end */
