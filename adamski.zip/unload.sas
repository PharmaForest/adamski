filename PB64CE1D list;
%put NOTE: Unloading package Adamski, version 0.0.9, license Apache license 2.0;
%put NOTE- *** START ***;
proc sql;
  create table WORK._%sysfunc(datetime(), hex16.)_ as
  select memname, objname, objtype
  from dictionary.catalogs
  where 
  (
   objname in ("*"
   ,'ADAMSKIMETA'
   ,'ADAMSKIIML'
   ,'ADAMSKICASLUDF'
   %put NOTE- Element of type macro generated from the file "derive_basetype_records.sas" will be deleted;
   %put NOTE- ;
   ,"DERIVE_BASETYPE_RECORDS                                         "
   %put NOTE- Element of type macro generated from the file "derive_locf_records.sas" will be deleted;
   %put NOTE- ;
   ,"DERIVE_LOCF_RECORDS                                             "
   %put NOTE- Element of type macro generated from the file "derive_var_age_years.sas" will be deleted;
   %put NOTE- ;
   ,"DERIVE_VAR_AGE_YEARS                                            "
   %put NOTE- Element of type macro generated from the file "derive_var_analysis_ratio.sas" will be deleted;
   %put NOTE- ;
   ,"DERIVE_VAR_ANALYSIS_RATIO                                       "
   %put NOTE- Element of type macro generated from the file "derive_var_base.sas" will be deleted;
   %put NOTE- ;
   ,"DERIVE_VAR_BASE                                                 "
   %put NOTE- Element of type macro generated from the file "derive_var_chg.sas" will be deleted;
   %put NOTE- ;
   ,"DERIVE_VAR_CHG                                                  "
   %put NOTE- Element of type macro generated from the file "derive_var_extreme_flag.sas" will be deleted;
   %put NOTE- ;
   ,"DERIVE_VAR_EXTREME_FLAG                                         "
   %put NOTE- Element of type macro generated from the file "derive_var_merged_exist_flag.sas" will be deleted;
   %put NOTE- ;
   ,"DERIVE_VAR_MERGED_EXIST_FLAG                                    "
   %put NOTE- Element of type macro generated from the file "derive_var_obs_number.sas" will be deleted;
   %put NOTE- ;
   ,"DERIVE_VAR_OBS_NUMBER                                           "
   %put NOTE- Element of type macro generated from the file "derive_var_pchg.sas" will be deleted;
   %put NOTE- ;
   ,"DERIVE_VAR_PCHG                                                 "
   %put NOTE- Element of type macro generated from the file "derive_var_trtdurd.sas" will be deleted;
   %put NOTE- ;
   ,"DERIVE_VAR_TRTDURD                                              "
   %put NOTE- Element of type macro generated from the file "derive_vars_aage.sas" will be deleted;
   %put NOTE- ;
   ,"DERIVE_VARS_AAGE                                                "
   %put NOTE- Element of type macro generated from the file "derive_vars_cat.sas" will be deleted;
   %put NOTE- ;
   ,"DERIVE_VARS_CAT                                                 "
   %put NOTE- Element of type macro generated from the file "derive_vars_duration.sas" will be deleted;
   %put NOTE- ;
   ,"DERIVE_VARS_DURATION                                            "
   %put NOTE- Element of type macro generated from the file "derive_vars_dy.sas" will be deleted;
   %put NOTE- ;
   ,"DERIVE_VARS_DY                                                  "
   %put NOTE- Element of type macro generated from the file "derive_vars_joined.sas" will be deleted;
   %put NOTE- ;
   ,"DERIVE_VARS_JOINED                                              "
  )
  and objtype = "MACRO"
  and libname  = "WORK"
  )
  or
  (
   objname in ("*"
  )
  and objtype in ("FORMAT" "FORMATC" "INFMT" "INFMTC")
  and libname  = "WORK"
  and memname = 'ADAMSKIFORMAT'
  )
  order by objtype, memname, objname
  ;
quit;
data _null_;
  do until(last.memname);
    set WORK._last_;
    by objtype memname;
    if first.memname then call execute("proc catalog cat = work." !! strip(memname) !! " force;");
    call execute("delete " !! strip(objname) !! " /  et =" !! objtype !! "; run;");
  end;
  call execute("quit;");
run;
proc delete data = WORK._last_;
run;
proc fcmp outlib = work.Adamskifcmp.package;
quit;

proc fcmp outlib = work.Adamskifcmp.packagemeta;
deletefunc AdamskiMETA;
quit;

options cmplib = (%unquote(%sysfunc(tranwrd(
%sysfunc(lowcase(%sysfunc(getoption(cmplib))))
,%str(work.adamskifcmp), %str() ))));
options cmplib = (%unquote(%sysfunc(compress(
%sysfunc(getoption(cmplib))
,%str(()) ))));
%put; %put NOTE:[CMPLIB] %sysfunc(getoption(cmplib));
proc SQL noprint;
quit;

data _null_; call symputx("_DS2_2_del_",0,"L"); run;
proc SQL noprint;
quit;

run;

data _null_ ;                                                                                         
  length SYSloadedPackages $ 32767;                                                                   
  if SYMEXIST("SYSloadedPackages") = 1 and SYMGLOBL("SYSloadedPackages") = 1 then                     
    do;                                                                                               
      do until(EOF);                                                                                  
        set sashelp.vmacro(where=(scope="GLOBAL" and name="SYSLOADEDPACKAGES")) end=EOF;              
        substr(SYSloadedPackages, 1+offset, 200) = value;                                             
      end;                                                                                            
      SYSloadedPackages = cats("#", translate(strip(SYSloadedPackages), "#", " "), "#");              
      if INDEX(lowcase(SYSloadedPackages),'#adamski(0.0.9)#')>0 then 
         do;                                                                                          
          SYSloadedPackages = tranwrd(SYSloadedPackages, '#Adamski(0.0.9)#', '##');  
          SYSloadedPackages = compbl(translate(SYSloadedPackages, " ", "#"));                         
          call symputX("SYSloadedPackages", SYSloadedPackages, "G");                                  
          put "NOTE: " SYSloadedPackages = ;                                                          
         end ;                                                                                        
    end;                                                                                              
  stop;                                                                                               
run;                                                                                                  
%put NOTE: Unloading package Adamski, version 0.0.9, license Apache license 2.0;
%put NOTE- *** END ***;
%put NOTE- ;
/* unload.sas end */
