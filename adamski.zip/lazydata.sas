filename PB64CE1D list;
 %put NOTE- ;
 %put NOTE: Data for package Adamski, version 0.0.8, license Apache license 2.0; 
 %put NOTE: *** %superq(packageTitle) ***; 
 %put NOTE- Generated: 2026-05-17T10:06:46; 
 %put NOTE- Author(s): %superq(packageAuthor); 
 %put NOTE- Maintainer(s): %superq(packageMaintainer); 
 %put NOTE- ;
 %put NOTE- Write %nrstr(%%)helpPackage(Adamski) for the description;
 %put NOTE- ;
 %put NOTE- *** START ***; 

data _null_;
 length lazyData $ 32767; lazyData = lowcase(symget("lazyData"));
run;
%put NOTE- ;
%put NOTE: Data for package Adamski, version 0.0.8, license Apache license 2.0;
%put NOTE- *** END ***;
/* lazydata.sas end */
